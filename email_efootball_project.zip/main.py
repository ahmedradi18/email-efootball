
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import os

app = FastAPI()

os.makedirs("templates", exist_ok=True)
os.makedirs("static", exist_ok=True)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

mailboxes = {}

class Message(BaseModel):
    sender: str
    subject: str
    content: str

@app.get("/", response_class=HTMLResponse)
async def homepage(request: Request, lang: str = "en"):
    return templates.TemplateResponse("index.html", {"request": request, "lang": lang})

@app.post("/create", response_class=HTMLResponse)
async def create_mailbox(request: Request, name: str = Form(...), lang: str = Form("en")):
    email = f"{name}@catdogmail.live"
    mailboxes.setdefault(email, [])
    return templates.TemplateResponse("inbox.html", {"request": request, "email": email, "messages": mailboxes[email], "lang": lang})

@app.post("/send", response_class=HTMLResponse)
async def send_message(request: Request, email: str = Form(...), sender: str = Form(...),
                       subject: str = Form(...), content: str = Form(...), lang: str = Form("en")):
    msg = Message(sender=sender, subject=subject, content=content)
    mailboxes.setdefault(email, []).append(msg)
    return templates.TemplateResponse("inbox.html", {"request": request, "email": email, "messages": mailboxes[email], "lang": lang})

@app.get("/inbox/{email}", response_class=HTMLResponse)
async def inbox(request: Request, email: str, lang: str = "en"):
    full_email = f"{email}@catdogmail.live"
    return templates.TemplateResponse("inbox.html", {"request": request, "email": full_email, "messages": mailboxes.get(full_email, []), "lang": lang})
